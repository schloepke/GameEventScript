<!-- Copyright 2026 Stephan Schlöpke -->
<!-- SPDX-License-Identifier: Apache-2.0 -->

# GameEventScript Assembler TextMate Bundle

This bundle provides modern JSON TextMate-compatible syntax highlighting for
GameEventScript assembler files (`.gesa`).

## Install

Copy or symlink `GameEventScriptAssembler.tmbundle` into a TextMate-compatible
bundle location, then reload bundles in the editor.

Common examples:

- TextMate: `~/Library/Application Support/TextMate/Bundles/`

Use this variant for tooling that accepts `.tmLanguage.json` and
`.tmPreferences.json`. For CodeRunner 4, use the sibling `TextMate Classic`
bundle instead.

The grammar is intentionally lightweight. It highlights `.gesa` directives,
segments, labels, opcodes, registers, immediates, bind kinds, type names,
comments, and strings. Version directives such as `.program-version 42` are
recognized explicitly. If embedded debug symbols are present in a dump,
`r20(total)` highlights `r20` as the physical register and `total` as its source
variable annotation; execution flags such as `NormalizeResultAsPredicate` retain
their separate constant scope. Source archives in
`.segment source "name.ges"` blocks and the source portion of
`.source-line "name.ges" 4 | source` use the normal GameEventScript source
grammar. A source segment ends at `.region-end "Name"` or the next `.segment`
directive. Free `.region "Name"` / `.region-end "Name"` blocks wrap dump
segments, use a comment scope, and are exposed through the standard TextMate
folding markers.

## Commands and completion

The bundle also includes optional TextMate CLI commands. Install `ges` on the
editor's PATH. The source bundle offers Check (Command-B), Compile, Run and Dump;
the assembler bundle offers Dump of its sibling `.gesb`. Commands save the active
file and show output with clickable diagnostic locations. Grammar-only importers
may not support these commands.

The source bundle additionally offers syntax-only completion and the Tab snippets
`ges-on`, `ges-iflet`, `ges-fold`, `ges-reduce`, and `ges-after`. There is no
semantic analysis. See the [editor guide](https://gameeventscript.org/docs/tools/editor-bundles/)
for scope, installation and CLI requirements. Use the separate Sublime package
for Sublime Text and bat.
